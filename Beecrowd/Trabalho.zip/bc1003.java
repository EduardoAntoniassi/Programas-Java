import java.io.IOException;
import java.util.Scanner;
public class bc1003 {
 
    public static void main(String[] args) throws IOException {

    Scanner s = new Scanner(System.in);
     
    int a = s.nextInt();
    int b = s.nextInt();
    int soma = a + b;
    
    System.out.printf("SOMA = %d\n" ,soma);
 
    }
 
}