import java.io.IOException;
public class Main {
 
    public static void main(String[] args) throws IOException {
 
        int set;
        set = 1;
        
    for (int i = 0; i < 5; i++) {
     
     System.out.printf("I=%d J=7\n" ,set);  
     System.out.printf("I=%d J=6\n" ,set);
     System.out.printf("I=%d J=5\n" ,set); 
     
     set = set + 2;
    }
    }
 
}